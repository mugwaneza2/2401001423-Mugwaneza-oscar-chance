create database road_management_system;

use road_management_system;

create table road(roadID int primary key,
roadname varchar(50),
length varchar(260)
);

create table traffic(reportedID int primary key,
roadID int,
policeid int,
traffic_account varchar(50),
date date,foreign key(policeid) references police (policeid)
);
drop table traffic;
desc traffic;
alter table traffic add constraint Road_traffic
foreign key(roadID) references road(roadID);
alter table traffic add column policeid int after roadID;

create table police(policeid int primary key,
policename varchar(60),
email varchar(100),
role varchar(50),
phone varchar(50)
);
drop table police;

insert into road (roadID,roadname,length)
values
 (250,'light',5555),
 (260,'nyak',6666),
 (270,'night',7777),
 (280,'mus',8888);
 select * from road;
 create view allroads as 
 select * from road;
 select * from allroads;
 insert into police (policeid,policename,email,role,phone) 
 values(10,'capt','capt@gmail.com','control',12356789),
 (20,'gen','gen@gmail.com','manage',987654321),
 (30,'Rut','ru@gmail.com','govern',978645321),
 (40,'private','private@gmail.com','order',132457689);
 select * from police;
 create  view allpolices as
select * from police;
select * from allpolices;
 -- MUgwaneza oscar chance 2401001423
 --  insert in traffic
 
 insert into traffic (reportedID,roadID ,policeid,traffic_account,date)
  values (9876,250,10,'554','2023-12-12');
   insert into traffic (reportedID,roadID ,policeid,traffic_account,date)
  values 
  (1876,260,20,'444','2003-11-02'),
  (5586,270,30,'644','2004-09-12'),
  (1346,280,20,'484','2009-01-22');
  select * from traffic;
 create  view alltraffics as
select * from traffic;
select * from alltraffics;

-- create view of name

-- Mugwaneza oscar chance
create view listtraff as select reportedID,date from traffic;
select * from listtraff;

-- create view of name 

create view listroad as select roadname,length from road;
select * from listroad;


-- create view of name
create view listpolice as select policename,email from police;
select * from listpolice;


---- stored procedure
delimiter $$
create procedure seltraffic(in repor int)
begin
select * from traffic where reportedID=repor;
end $$
delimiter ;
call seltraffic(5586);

delimiter $$
create procedure upffic(in trat int)
begin
update  traffic set traffic_account='333' where reportedID=trat;
end $$
delimiter ;
call upffic(1876);

---- stored procedure
delimiter $$
create procedure selpolice(in chance int)
begin
select * from police where policeid=chance;
end $$
delimiter ;
call selpolice(10);

----  stored procudure
delimiter $$
create procedure selroa(in osk int)
begin
select * from road where roadID=osk;
end $$
delimiter ;
call selroa(250);


--  stored procedure

delimiter $$ 
create procedure inserroad(in roap int,in roan varchar(100), in lenp int)
begin
insert into road values(roap,roan,lenp);
end $$
delimiter ; 
call inserroad(290,'bushozi',1010);



delimiter $$
create procedure dellroa(in roid int)
begin
delete from road where roadID=roid;
end $$
delimiter ;
call dellroa(290);

delimiter $$
create procedure inserpoli(in polid int,in poliame varchar(50),in emai varchar(50),in roe varchar(40),in phon int)
begin
insert into police values(polid,poliame,emai,roe,phon);
end $$
delimiter ;
call inserpoli(50,'ruti','soli@gmail.com','collect',098765432);






